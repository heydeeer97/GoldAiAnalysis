# Gold AI Analyst — Android starter project

Стартовый Android-проект на Kotlin + Jetpack Compose.

## Уже реализовано
- Русский интерфейс Minimal Dark.
- Экраны «Обзор», «График», «История».
- Переключение M15 / H1.
- Встроенный TradingView Advanced Chart widget (OANDA:XAUUSD).
- Честные состояния «Данные не подключены» и «NO TRADE».

## Пока не реализовано
- Реальные котировки для аналитического движка.
- Расчёт BUY/SELL.
- SMC, BOS/CHoCH, ликвидность, FVG и Order Blocks.
- Backend API, Telegram и база истории сигналов.

## Сборка APK
1. Откройте папку проекта в Android Studio.
2. Установите Android SDK 35 и JDK 17.
3. Дождитесь Gradle Sync.
4. Выберите Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## TradingView
График загружается через встраиваемый виджет TradingView и требует интернета. Доступность инструмента и котировок зависит от TradingView и выбранного источника. Перед публикацией приложения проверьте актуальные условия использования TradingView.
