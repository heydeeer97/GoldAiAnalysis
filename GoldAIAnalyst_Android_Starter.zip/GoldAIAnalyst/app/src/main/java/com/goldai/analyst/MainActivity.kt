package com.goldai.analyst

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Bg = Color(0xFF0B0D10)
private val Panel = Color(0xFF15191F)
private val Panel2 = Color(0xFF1C222B)
private val Muted = Color(0xFF9AA4B2)
private val Accent = Color(0xFFE5B94B)
private val White = Color(0xFFF4F6F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldApp() }
    }
}

@Composable
fun GoldApp() {
    var selectedTab by remember { mutableStateOf("Обзор") }
    var timeframe by remember { mutableStateOf("15") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = White, onSurface = White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selectedTab == "Обзор", { selectedTab = "Обзор" },
                        icon = { Icon(Icons.Default.Analytics, null) }, label = { Text("Обзор") })
                    NavigationBarItem(selectedTab == "График", { selectedTab = "График" },
                        icon = { Icon(Icons.Default.ShowChart, null) }, label = { Text("График") })
                    NavigationBarItem(selectedTab == "История", { selectedTab = "История" },
                        icon = { Icon(Icons.Default.History, null) }, label = { Text("История") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(horizontal = 16.dp)) {
                Header()
                when (selectedTab) {
                    "Обзор" -> Overview(timeframe, { timeframe = it }, { selectedTab = "График" })
                    "График" -> ChartScreen(timeframe, { timeframe = it })
                    else -> HistoryScreen()
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 18.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("GOLD AI ANALYST", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("АНАЛИТИКА XAU/USD", color = Muted, fontSize = 11.sp, letterSpacing = 1.4.sp)
        }
        Surface(color = Panel2, shape = RoundedCornerShape(50)) {
            Text("ДЕМО-РЕЖИМ", color = Accent,
                modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp),
                fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Overview(timeframe: String, onTimeframeChange: (String) -> Unit, onOpenChart: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text("Золото / Доллар США", color = Muted, fontSize = 12.sp)
                Text("XAU/USD", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Text("● Данные не подключены", color = Accent, fontSize = 10.sp)
        }
        CardBlock {
            Text("ПОСЛЕДНЯЯ ЦЕНА", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))
            Text("—", color = White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("Подключите источник котировок для отображения цены", color = Muted, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TimeButton("15", timeframe == "15") { onTimeframeChange("15") }
            Spacer(Modifier.width(8.dp))
            TimeButton("60", timeframe == "60") { onTimeframeChange("60") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onOpenChart) { Text("Открыть график", color = Accent) }
        }
        CardBlock {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ТОРГОВЫЙ СИГНАЛ", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("ОЖИДАНИЕ", color = Accent, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) {
                    Text("NO TRADE", color = Accent, modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Сигналы появятся после подключения данных и запуска проверенной стратегии.",
                color = Muted, fontSize = 12.sp)
        }
        CardBlock {
            Text("АНАЛИТИЧЕСКИЕ ФАКТОРЫ", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(12.dp))
            FactorRow("Тренд H1", "Нет данных")
            FactorRow("Структура M15", "Нет данных")
            FactorRow("Ликвидность", "Нет данных")
            FactorRow("Объём", "Нет данных")
            FactorRow("RSI / MACD", "Нет данных")
        }
        Text("Стартовый интерфейс: реальные котировки и торговые сигналы ещё не подключены.",
            color = Muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 12.dp))
    }
}

@Composable
fun ChartScreen(timeframe: String, onTimeframeChange: (String) -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ГРАФИК XAU/USD", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeButton("15", timeframe == "15") { onTimeframeChange("15") }
            TimeButton("60", timeframe == "60") { onTimeframeChange("60") }
        }
        TradingViewChart(timeframe, Modifier.fillMaxWidth().weight(1f))
        Text("График загружается из TradingView и требует интернет-соединения.",
            color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun TradingViewChart(timeframe: String, modifier: Modifier = Modifier) {
    val html = remember(timeframe) {
        """
        <!DOCTYPE html><html><head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        html,body{margin:0;padding:0;background:#0B0D10;height:100%}
        .tradingview-widget-container{height:100%;width:100%}
        .tradingview-widget-container__widget{height:100%;width:100%}
        </style></head><body>
        <div class="tradingview-widget-container">
          <div class="tradingview-widget-container__widget"></div>
          <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>
          {
            "autosize": true,
            "symbol": "OANDA:XAUUSD",
            "interval": "$timeframe",
            "timezone": "Europe/Warsaw",
            "theme": "dark",
            "style": "1",
            "locale": "ru",
            "allow_symbol_change": true,
            "calendar": false,
            "support_host": "https://www.tradingview.com"
          }
          </script>
        </div></body></html>
        """.trimIndent()
    }
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webChromeClient = WebChromeClient()
                webViewClient = WebViewClient()
                setBackgroundColor(android.graphics.Color.rgb(11, 13, 16))
                loadDataWithBaseURL("https://www.tradingview.com", html, "text/html", "UTF-8", null)
            }
        },
        update = { it.loadDataWithBaseURL("https://www.tradingview.com", html, "text/html", "UTF-8", null) }
    )
}

@Composable
fun HistoryScreen() {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ИСТОРИЯ СИГНАЛОВ", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
        CardBlock {
            Text("Пока нет сигналов", color = White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("После подключения аналитического сервера здесь будут BUY, SELL и NO TRADE.",
                color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun TimeButton(label: String, selected: Boolean, onClick: () -> Unit) {
    val title = if (label == "15") "M15" else "H1"
    Surface(onClick = onClick, color = if (selected) Accent else Panel2,
        shape = RoundedCornerShape(10.dp)) {
        Text(title, color = if (selected) Bg else White,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun FactorRow(name: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(name, color = White, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = Muted, fontSize = 11.sp)
    }
}
